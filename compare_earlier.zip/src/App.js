import './App.css';
import Prducts from './Components/Products';

function App() {
  return (
    <div className="App">
      <Prducts />
    </div>
  );
}

export default App;
