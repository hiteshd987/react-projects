import React from 'react'

function Products_Compare(props) {
    return (
        <div>
            <h1>Insideeeeeeeeeee</h1>
            console.log("Inside");
            <p>{props.visible}</p>

            {/* <p>{id}</p>
            <p>{name}</p>
            <p>{price}</p>
            <p>{condition}</p>
            <p>{colors}</p> */}
        </div>
    )
}

export default Products_Compare
