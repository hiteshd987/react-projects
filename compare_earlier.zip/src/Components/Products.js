import React, { useState } from 'react';
import { Card, Container, Row, Col, Button } from 'react-bootstrap';
import './Products.css';
import Products_Compare from "./Products_Compare";

function Products() {

     const [ items, setItems ] = useState([]);
     const visible = false;

    const compare = () => {
        // setItems([ ...items, { 
        //     visible: !visible,
        //     id: items.length,
        //     name: "cherry" 
        // }])
        setItems({ visible: !items.visible })
        console.log(visible);
    }

    return (
        <div className="products">
                <Container fluid>
                    <div className="products-main">
                        <Row className="products-main1">
                            <h1>Compare Products</h1>
                        </Row>
                        <Row className="products-main2">
                            <Col>
                                <Card className="products-card">
                                    <Card.Img className="products-card-image" src="https://images.pexels.com/photos/109274/pexels-photo-109274.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" />
                                    <Card.Body>
                                        <Card.Title className="products-card-title">Cherry</Card.Title>
                                        <Card.Text className="products-card-text">
                                            Two Cherries
                                        </Card.Text>
                                        <Card.Text className="products-card-price">
                                            $1.99
                                        </Card.Text>
                                        <div class="products-card-compare">
                                            <Button onClick={compare} class="products-card-compare-button">Compare</Button>
                                        </div>
                                    </Card.Body>
                                </Card> 
                            </Col>
                            <Col>
                                <Card className="products-card">
                                    <Card.Img className="products-card-image" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTs_4lTKgOKLX7I-v9ErQbsjLbrMyLrNKyJHA&usqp=CAU" />
                                    <Card.Body>
                                        <Card.Title className="products-card-title">Orange</Card.Title>
                                        <Card.Text className="products-card-text">
                                           Giant Orange
                                        </Card.Text>
                                        <Card.Text className="products-card-price">
                                            $2.99
                                        </Card.Text>
                                        <div class="products-card-compare">
                                            <Button class="products-card-compare-button">Compare</Button>
                                        </div>
                                    </Card.Body>
                                </Card> 
                            </Col>
                            <Col>
                                <Card className="products-card">
                                    <Card.Img className="products-card-image" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSYl6kDJO2dzbeWVhploOfgIhfj9Lk91ZUpQ&usqp=CAU" />
                                    <Card.Body>
                                        <Card.Title className="products-card-title">Nuts</Card.Title>
                                        <Card.Text className="products-card-text">
                                            Mixed Nuts
                                        </Card.Text>
                                        <Card.Text className="products-card-price">
                                            $1.00
                                        </Card.Text>
                                    </Card.Body>
                                </Card> 
                            </Col>
                            <Col>
                                <Card className="products-card">
                                    <Card.Img className="products-card-image" src="https://i0.wp.com/herrles.com/wp-content/uploads/2020/04/78471.jpg?fit=3951%2C3617&ssl=1" />
                                    <Card.Body>
                                        <Card.Title className="products-card-title">Strawberry</Card.Title>
                                        <Card.Text className="products-card-text">
                                            Just Strawberry
                                        </Card.Text>
                                        <Card.Text className="products-card-price">
                                            $1.49
                                        </Card.Text>
                                    </Card.Body>
                                </Card> 
                            </Col>
                        </Row>
                    </div>
                </Container>
                <div>
                { items.visible ? <Products_Compare items /> : null }
                </div>
        </div>
    )
}

export default Products
